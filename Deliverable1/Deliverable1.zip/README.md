App repository link: 
https://github.com/angemichaella/android-school-project

Group YAAS is made of 4 people:
* Aisha Khalid - akhal096@uottawa.ca
* Ange Michaella Niyonkuru - aniyo066@uottawa.ca
* Shiza Siddiqui - ssidd021@uottawa.ca
* Yusra Adinoyi - yadin030@uottawa.ca

app icons credits to Freepik: https://www.freepik.com/